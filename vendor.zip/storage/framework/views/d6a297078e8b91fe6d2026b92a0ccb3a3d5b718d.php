<?php $__env->startSection('content'); ?>

<div class="container">
<h2><?php echo e($book->name); ?></h2>

<p>
<?php echo e($book->description); ?>

</p>

<h3><?php echo e($book->created_at); ?></h3>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\larastart\resources\views/book/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<h2> Add New Book</h2>

<?php echo Form::open(['method' => 'POST', 'route' => 'book.store']); ?>

<div Class="form-group">
<?php echo Form::text('name',null,['class' =>'form-control','placeholder' => 'Please Enter The Book Name']); ?>

</div>

<div Class="form-group">
<?php echo Form::textarea('description',null,['class' =>'form-control','placeholder' => 'Please Enter The Book Description']); ?>

</div>

<div Class="form-group">
<input type="submit" class="btn btn-primary" value = "Add">
</div>
<?php echo e(Form::close()); ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\larastart\resources\views/book/create.blade.php ENDPATH**/ ?>